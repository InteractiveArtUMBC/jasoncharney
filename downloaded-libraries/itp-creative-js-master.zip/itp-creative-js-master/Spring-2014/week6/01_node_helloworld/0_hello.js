// This is a JS program that we can run
// from the command line saying 
// $ node hello0.js

console.log("hello");